function varargout = vistool(varargin)
%-------------------------------------------------------------------------------
%
%                           vistool
%
%-------------------------------------------------------------------------------
%
% Copyright (c) 2009 Trustees of Dartmouth College
% Written by Ethan K Murphy
% Hanover 15 December 2014
% 
% If this software is used please reference the following work:
% 
% Murphy EK, Mahara A, Odame KM, and Halter RJ EIT SysDAF: Electrical Impedance 
% Tomography System Design and feasibility Analysis Framework, submitted to
% Physiological Measurement December 2014
% 
%-------------------------------------------------------------------------------
% VISTOOL MATLAB code for vistool.fig
%      VISTOOL, by itself, creates a new VISTOOL or raises the existing
%      singleton*.
%
%      H = VISTOOL returns the handle to a new VISTOOL or the handle to
%      the existing singleton*.
%
%      VISTOOL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in VISTOOL.M with the given input arguments.
%
%      VISTOOL('Property','Value',...) creates a new VISTOOL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before vistool_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to vistool_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help vistool

% Last Modified by GUIDE v2.5 16-Dec-2014 15:06:15

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @vistool_OpeningFcn, ...
                   'gui_OutputFcn',  @vistool_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

%--------------------------------------------------------------------------
% Set globals
global dbmat clabs nvar extcond_fun nodes qplt_lims recdat
addpath(genpath('mfiles'))
addpath(genpath('data'))

%--------------------------------------------------------------------------
if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before vistool is made visible.
function vistool_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to vistool (see VARARGIN)

% Choose default command line output for vistool
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);



% UIWAIT makes vistool wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = vistool_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


%--------------------------------------------------------------------------
%
% This function loads the input data needed for the visualization
%
%--------------------------------------------------------------------------
function input_data_Callback(hObject, eventdata, handles)
%--------------------------------------------------------------------------
% Set globals
global dbmat clabs nvar extcond_fun nodes plot_info numsamp recdat
recdat = [];
%--------------------------------------------------------------------------
% Open a GUI for selecting a mat-file
% uiopen('data\summary_data\','mat')
fname = uigetfile('data/summary_data/*.mat');
eval(['load data/summary_data/',fname])

%--------------------------------------------------------------------------
% Load the reconstruction mesh
eval(['load ',mesh_fname])

%--------------------------------------------------------------------------
% Set the possible plotting variables
set(handles.plot_varx,    'String',clabs(1:nvar))
set(handles.plot_vary,    'String',clabs(1:nvar))
set(handles.plot_varx,    'Value',1)
set(handles.plot_vary,    'Value',2)
set(handles.plotvarx_rec_txtbox,'String',[clabs{1},':'])
set(handles.plotvary_rec_txtbox,'String',[clabs{2},':'])

%--------------------------------------------------------------------------
% Set the constant variable names and values
if nvar > 2
    set(handles.const_varname1,'String',clabs{3})
    set(handles.const_vals1,  'String', num2cell(unique(dbmat(:,3))))
    if nvar > 3
        set(handles.const_varname2,'String',clabs{4})
        set(handles.const_vals2,  'String', num2cell(unique(dbmat(:,4))))
        if nvar > 4
            set(handles.const_varname3,'String',clabs{4})
            set(handles.const_vals3,  'String', num2cell(unique(dbmat(:,4))))
            if nvar > 5
                error('Needs to be updated for this many variables')
            end
        else
            set(handles.const_varname3,'String','NO OTHER VARS')
            set(handles.const_vals3,  'String', 'NA')
        end
    else
        set(handles.const_varname2,'String','NO OTHER VARS')
        set(handles.const_vals2,  'String', 'NA')
        set(handles.const_varname3,'String','NO OTHER VARS')
        set(handles.const_vals3,  'String', 'NA')    
    end
else
    set(handles.const_varname1,'String','NO OTHER VARS')
    set(handles.const_vals1,  'String', 'NA')
    set(handles.const_varname2,'String','NO OTHER VARS')
    set(handles.const_vals2,  'String', 'NA')
    set(handles.const_varname3,'String','NO OTHER VARS')
    set(handles.const_vals3,  'String', 'NA')    
end
%--------------------------------------------------------------------------
% Set the default plotting options
qual_strings = clabs(nvar+1:end);
set(handles.plot_1opt,'String',qual_strings)
if length(qual_strings) > 1
    set(handles.plot_2opt,'String',clabs(nvar+1:end))
    set(handles.plot_2opt,'Value',2)
end
if length(qual_strings) > 2
    set(handles.plot_3opt,'String',clabs(nvar+1:end))
    set(handles.plot_3opt,'Value',3)
end
update_selaxis_opts(handles);

%--------------------------------------------------------------------------
% Initialize the selected point to be -1, -1
plot_info.selpnt = [-1 -1];

%--------------------------------------------------------------------------
% Set the slice value and slider to the middle z-value
avez = mean(unique(nodes(:,3)));
set(handles.slice_val,'String',num2str(avez))
set(handles.slice_slide,'Value',0.5)

%-------------------------------------------------------------------------------
%
% These callback functions are activated when the plotting function is
% changed.  When this happens we need to update the constant variables.
%
%-------------------------------------------------------------------------------
% Plot variable x
function plot_varx_Callback(hObject, eventdata, handles)
%-------------------------------------------------------------------------------
update_const_var_list(handles)
%-------------------------------------------------------------------------------
function plot_vary_Callback(hObject, eventdata, handles)
update_const_var_list(handles)
%-------------------------------------------------------------------------------
function update_const_var_list(handles)
%-------------------------------------------------------------------------------
% Set globals
global dbmat clabs nvar extcond_fun nodes plot_info
%--------------------------------------------------------------------------
% Update the constant variables if there are more than one variable
plotvarx_ind = get(handles.plot_varx,'Value');    
plotvary_ind = get(handles.plot_vary,'Value');    
if nvar > 2
    %----------------------------------------------------------------------
    % Get the indices of the constant variables
    cons_vars   = setdiff(1:nvar,[plotvarx_ind plotvary_ind]);
    %----------------------------------------------------------------------
    % Set the constant variable names and the first names values
    set(handles.const_varname1,'String',clabs{cons_vars(1)})
    tmp = unique(dbmat(:,cons_vars(1)));
    for n = 1:length(tmp)
        tmpcell1{n} = num2str(tmp(n));
    end
    set(handles.const_vals1,   'String', tmpcell1)
    if nvar > 3
        set(handles.const_varname2,'String',clabs{cons_vars(2)})
        tmp = unique(dbmat(:,cons_vars(2)));
        for n = 1:length(tmp)
            tmpcell2{n} = num2str(tmp(n));
        end
        set(handles.const_vals2,   'String', tmpcell2)
        if nvar > 4
            set(handles.const_varname3,'String',clabs{cons_vars(3)})             
            tmp = unique(dbmat(:,cons_vars(3)));
            for n = 1:length(tmp)
                tmpcell3{n} = num2str(tmp(n));
            end            
            set(handles.const_vals3,   'String', tmpcell3)
        end
    end
end
set(handles.plotvarx_rec_txtbox,'String',[clabs{plotvarx_ind},':'])
set(handles.plotvary_rec_txtbox,'String',[clabs{plotvary_ind},':'])


%--------------------------------------------------------------------------
%
% The following 3 functions handle which quality metric goes into which
% plot.
%
%--------------------------------------------------------------------------
% Plot 1.
function plot_1opt_Callback(hObject, eventdata, handles)
global clabs nvar
update_selaxis_opts(handles);
%--------------------------------------------------------------------------
% Plot 2.
function plot_2opt_Callback(hObject, eventdata, handles)
global clabs nvar
update_selaxis_opts(handles);
%--------------------------------------------------------------------------
% Plot 3.
function plot_3opt_Callback(hObject, eventdata, handles)
global clabs nvar
update_selaxis_opts(handles);
%--------------------------------------------------------------------------
function update_selaxis_opts(handles)
global clabs nvar
%--------------------------------------------------------------------------
% Update the first string in the point select axis
qual_strings = clabs(nvar+1:end);
sel_opts{1}  = qual_strings{get(handles.plot_1opt,'Value')};
set(handles.qualmet1_str,'String',[sel_opts{1},':'])
if length(qual_strings) > 1
    sel_opts{2}  = qual_strings{get(handles.plot_2opt,'Value')};
    set(handles.qualmet2_str,'String',[sel_opts{2},':'])
end
if length(qual_strings) > 2
    sel_opts{3}  = qual_strings{get(handles.plot_3opt,'Value')};
    set(handles.qualmet3_str,'String',[sel_opts{3},':'])
end


%--------------------------------------------------------------------------
% 
% Make the plots based on the selected variables and quality metrics
%
%--------------------------------------------------------------------------
function start_view_data_Callback(hObject, eventdata, handles)
%--------------------------------------------------------------------------
% Set globals
global dbmat clabs nvar extcond_fun nodes plot_info
%--------------------------------------------------------------------------
% Get the plotting variable indices and strings
plot_var_strs  = get(handles.plot_varx,'String');
plot_varx_ind  = get(handles.plot_varx,'Value');
plot_vary_ind  = get(handles.plot_vary,'Value');
%--------------------------------------------------------------------------
% Get the constant variables indices and values
cons_inds = setdiff(1:nvar,[plot_varx_ind plot_vary_ind]);
if nvar > 2
    cons_strs    = get(handles.const_vals1,'String');
    cons_vals    = zeros(1,nvar - 2);
    cons_vals(1) = str2num(cons_strs{get(handles.const_vals1,'Value')});
    if nvar > 3
        cons_strs    = get(handles.const_vals2,'String');
        cons_vals(2) = str2num(cons_strs{get(handles.const_vals2,'Value')});
        if nvar > 4
            cons_strs    = get(handles.const_vals3,'String');
            cons_vals(3) = str2num(cons_strs{get(handles.const_vals3,'Value')});
            if nvar > 5
                error('this needs to be updated for more than 5 variables')
            end
        end
    end
end


%--------------------------------------------------------------------------
% Construct the 2D surface used for plotting
[var1_mat, var2_mat] = meshgrid( ...
    unique(dbmat(:,plot_varx_ind)),unique(dbmat(:,plot_vary_ind)));
%--------------------------------------------------------------------------
% Set the yaxis label
xlab_str = plot_var_strs{plot_varx_ind};
ylab_str = plot_var_strs{plot_vary_ind};

%--------------------------------------------------------------------------
% Reduce the total database to those that have the selected constant value
% inds = find(abs( dbmat(:,cons_inds) - cons_vals) < 1e-6);
if isempty(cons_inds) == 0
    inds = find(sqrt(sum( ...
        ( dbmat(:,cons_inds) - repmat(cons_vals,size(dbmat,1),1) ).^2,2)) < 1e-4);
else
    inds = 1:size(dbmat,1);
end
%--------------------------------------------------------------------------
% Get the indices of the dbmat for the selected plots
plotinds(1) = nvar + get(handles.plot_1opt,'Value');
plotinds(2) = nvar + get(handles.plot_2opt,'Value');
plotinds(3) = nvar + get(handles.plot_3opt,'Value');

%--------------------------------------------------------------------------
% Plot 1
zplot1_mat = griddata(          ...
    dbmat(inds,plot_varx_ind)   , ...       % All variable x values
    dbmat(inds,plot_vary_ind)   , ...       % All variable y values
    dbmat(inds,plotinds(1))     , ...       % Quality 1
    var1_mat                    , ...       % unique RMS
    var2_mat                    , ...       % unique variable 2 values
    'nearest');
%--------------------------------------------------------------------------
% Plot 2
zplot2_mat = griddata(          ...
    dbmat(inds,plot_varx_ind)   , ...       % All variable x values
    dbmat(inds,plot_vary_ind)   , ...       % All variable y values
    dbmat(inds,plotinds(2))     , ...       % Quality 2
    var1_mat                    , ...       % unique RMS
    var2_mat                    , ...       % unique variable 2 values
    'nearest');
%--------------------------------------------------------------------------
% Plot 3
zplot3_mat = griddata(          ...
    dbmat(inds,plot_varx_ind)   , ...       % All variable x values
    dbmat(inds,plot_vary_ind)   , ...       % All variable y values
    dbmat(inds,plotinds(3))     , ...       % Quality 3
    var1_mat                    , ...       % unique RMS
    var2_mat                    , ...       % unique variable 2 values
    'nearest');

%---------------------------------------------------------------------------
% Set the plot info structure array
plot_info.var1_mat   = var1_mat;
plot_info.var2_mat   = var2_mat;
plot_info.zplot1_mat = zplot1_mat;
plot_info.zplot2_mat = zplot2_mat;
plot_info.zplot3_mat = zplot3_mat;
plot_info.xlab_str   = xlab_str;
plot_info.ylab_str   = ylab_str;
plot_info.plotinds   = plotinds;
plot_info.qctol1     = 0;
plot_info.qctol2     = 0;
plot_info.qctol3     = 0;
% [plot_varx_ind plot_vary_ind]
plot_info.logscl     = ...
    plot_info.var_logscale([plot_varx_ind plot_vary_ind]);
plot_info.vtics     = ...
    plot_info.vplt_tics([plot_varx_ind plot_vary_ind]);

%---------------------------------------------------------------------------
% Call the function to make the plots
make_qual_plots(handles, plot_info)


%---------------------------------------------------------------------------
% Call the function to make the plots
function make_qual_plots(handles            , ...
    plot_info )
%--------------------------------------------------------------------------
% Set globals
global dbmat clabs nvar extcond_fun nodes  
%--------------------------------------------------------------------------
% Set parameters
dbg_flg      = 0;
var1_mat     = plot_info.var1_mat;
var2_mat     = plot_info.var2_mat;
zplot1_mat   = plot_info.zplot1_mat;
zplot2_mat   = plot_info.zplot2_mat;
zplot3_mat   = plot_info.zplot3_mat;
xlab_str     = plot_info.xlab_str;
ylab_str     = plot_info.ylab_str;
plotinds     = plot_info.plotinds;
selpnt       = plot_info.selpnt;
qplt_lims    = plot_info.qplt_lims;
logscl       = plot_info.logscl;
vplt_xtics   = plot_info.vtics{1};
vplt_ytics   = plot_info.vtics{2};
qctol1       = plot_info.qctol1;
qctol2       = plot_info.qctol2;
qctol3       = plot_info.qctol3;

%--------------------------------------------------------------------------
% Quality metric 0
hax = handles.qualmet_0;
plot_qual_metric(             ...
    var1_mat, var2_mat      , ...
    zplot1_mat              , ...
    logscl                  , ...
    vplt_xtics              , ...
    vplt_ytics              , ...
    xlab_str, ylab_str      , ...
    clabs{plotinds(1)}      , ...
    qplt_lims(plotinds(1)-nvar,:), ...
    selpnt(1),selpnt(2)     , ...
    hax                     , ...
    qctol1                  , ...
    dbg_flg )
%--------------------------------------------------------------------------
% Quality metric 1
hax = handles.qualmet_1;
plot_qual_metric(             ...
    var1_mat, var2_mat      , ...
    zplot2_mat              , ...
    logscl                  , ...
    vplt_xtics              , ...
    vplt_ytics              , ...    
    xlab_str, ylab_str      , ...
    clabs{plotinds(2)}      , ...
    qplt_lims(plotinds(2)-nvar,:), ...
    selpnt(1),selpnt(2)     , ...
    hax                     , ...
    qctol2                  , ...
    dbg_flg )
%--------------------------------------------------------------------------
% Quality metric 2
hax = handles.qualmet_2;
plot_qual_metric(             ...
    var1_mat, var2_mat      , ...
    zplot3_mat              , ...
    logscl                  , ...
    vplt_xtics              , ...
    vplt_ytics              , ...    
    xlab_str, ylab_str      , ...
    clabs{plotinds(3)}      , ...
    qplt_lims(plotinds(3)-nvar,:), ...
    selpnt(1),selpnt(2)     , ...
    hax                     , ...
    qctol3                  , ...
    dbg_flg )


%--------------------------------------------------------------------------
%
% This function makes a 2D plot of the reconstruction
%
%--------------------------------------------------------------------------
function plotrecon_Callback(hObject, eventdata, handles)
%--------------------------------------------------------------------------
% Set globals
global dbmat clabs nvar extcond_fun nodes qplt_lims plot_info  
%--------------------------------------------------------------------------
% Get the plotting variable index
plot_varx_ind  = get(handles.plot_varx,'Value');
plot_vary_ind  = get(handles.plot_vary,'Value');
%--------------------------------------------------------------------------
% Get the points and find the closest point in the DB
[x,y] = ginput(1);
%--------------------------------------------------------------------------
% Get the index of the y selected point
[~,yind]  = min(abs(dbmat(:,plot_vary_ind) - y));
selpnt(2) = dbmat(yind,plot_vary_ind);
%--------------------------------------------------------------------------
% Get the index of the x selected point
[~,xind]  = min(abs(dbmat(:,plot_varx_ind) - x));
selpnt(1) = dbmat(xind,plot_varx_ind);
%--------------------------------------------------------------------------
% Record the selected point
plot_info.selpnt = selpnt;

set(handles.rec_xvar_txtbox,'String',num2str(selpnt(1)))
set(handles.rec_yvar_txtbox,'String',num2str(selpnt(2)))

%-------------------------------------------------------------------------------
% Get index of the chosen point 
allvars = [plot_info.var1_mat(:) plot_info.var2_mat(:)];
[tmp, allind] = min(sum( (allvars - repmat([x y],size(allvars,1),1)).^2,2));
% Set the values of the quality metrics selected in the plot
tmp_qualm1 = plot_info.zplot1_mat(:);
tmp_qualm2 = plot_info.zplot2_mat(:);
tmp_qualm3 = plot_info.zplot3_mat(:);
set(handles.qualmet1_txtbx,'String',num2str( tmp_qualm1(allind) ))
set(handles.qualmet2_txtbx,'String',num2str( tmp_qualm2(allind) ))
set(handles.qualmet3_txtbx,'String',num2str( tmp_qualm3(allind) ))

%--------------------------------------------------------------------------
% Plot the quality metrics with the updated selected point
make_qual_plots(handles, plot_info )

%--------------------------------------------------------------------------
% Plot the reconstruction
plot_sel_rec(handles, plot_info )



%-------------------------------------------------------------------------------
%
% Plot the reconstruction
%
%-------------------------------------------------------------------------------
function plot_sel_rec(handles               , ...
    plot_info)
%-------------------------------------------------------------------------------
% Set globals
global dbmat clabs nvar extcond_fun nodes qplt_lims numsamp recdat
selpnt  = plot_info.selpnt;
dbg_flg = 0;
%-------------------------------------------------------------------------------
% Find the sample of interest
samp_ind = round((numsamp-1)*get(handles.sample_slider,'Value'))+1;
set(handles.sample_txtbox,'String',num2str(samp_ind))

%-------------------------------------------------------------------------------
%
% Set the parameter values
%
%-------------------------------------------------------------------------------
par_vals  = zeros(1,nvar);
%-------------------------------------------------------------------------------
% Plotting index
plot_varx_ind = get(handles.plot_varx,'Value');
plot_vary_ind = get(handles.plot_vary,'Value');
par_vals(plot_varx_ind) = selpnt(1);
par_vals(plot_vary_ind) = selpnt(2);
%-------------------------------------------------------------------------------
% Constant values
%--------------------------------------------------------------------------
% Get the constant variables indices and values
cons_inds = setdiff(1:nvar,[plot_varx_ind plot_vary_ind]);
if nvar > 2
    cons_strs    = get(handles.const_vals1,'String');
    cons_vals    = zeros(1,nvar - 2);
    cons_vals(1) = str2num(cons_strs{get(handles.const_vals1,'Value')});
    if nvar > 3
        cons_strs    = get(handles.const_vals2,'String');
        cons_vals(2) = str2num(cons_strs{get(handles.const_vals2,'Value')});
        if nvar > 4
            cons_strs    = get(handles.const_vals3,'String');
            cons_vals(3) = str2num(cons_strs{get(handles.const_vals3,'Value')});
            if nvar > 5
                error('this needs to be updated for more than 5 variables')
            end
        end
    end
end
if isempty(cons_inds) == 0
    par_vals(cons_inds) = cons_vals;
end

%-------------------------------------------------------------------------------
% Find all the nodes that have a value given by the slice axis and value chosen
slice_val = str2num( get(handles.slice_val,'String') );
if get(handles.xyplane_rbut,'Value') == 1
    %---------------------------------------------------------------------------
    % XY-plane, 
    delval      = 0.05 * (max(nodes(:,3)) - min(nodes(:,3)));
    topinds   = find( abs( nodes(:,3) - slice_val ) < delval);
    plane_ids = [1 2];
    
elseif get(handles.yzplane_rbut,'Value') == 1
    %---------------------------------------------------------------------------
    % YZ-plane, 
    delval    = 0.05 * (max(nodes(:,1)) - min(nodes(:,1)));
    topinds   = find( abs( nodes(:,1) - slice_val ) < delval);
    plane_ids = [2 3];
    
elseif get(handles.xzplane_rbut,'Value') == 1
    %---------------------------------------------------------------------------
    % XZ-plane, 
    delval    = 0.05 * (max(nodes(:,2)) - min(nodes(:,2)));
    topinds   = find( abs( nodes(:,2) - slice_val ) < delval);
    plane_ids = [1 3];
    
end

%-------------------------------------------------------------------------------
%
% Load the reconstructed conductivity data using the given function in the
% input data
%
%-------------------------------------------------------------------------------
[sig_vec, true_inc] =                             ...
    extcond_fun(                      ...
    par_vals                        , ...
    samp_ind                        , ...
    plane_ids                       , ...
    recdat );


%--------------------------------------------------------------------------
% Subset the mesh based on the chosen values
[topnodes,tmp] = unique(nodes(topinds,plane_ids),'rows');
topinds = topinds(tmp);
TRI     = delaunay(topnodes(:,1),topnodes(:,2));

%--------------------------------------------------------------------------
% Construct a grid of these top nodes values
[xmat,ymat] = meshgrid(linspace(min(topnodes(:,1)),max(topnodes(:,1)),100));

%--------------------------------------------------------------------------
% Set the caxis limits if there is one prescribed
if isfield(plot_info,'clim_2Drec') == 1
    clims = plot_info.clim_2Drec;
else
    clims = [min(sig_vec(:)) max(sig_vec(:))];
end

%--------------------------------------------------------------------------
% Produce the plot
thresh = str2num(get(handles.recon_thresh,'String'));
hax    = handles.Rec_axis;
plot_2d_sigrec( ...
    TRI,topnodes,sig_vec(topinds), ...
    xmat,ymat           , ...
    thresh              , ...
    true_inc            , ...
    clims               , ...    
    hax                 , ...
    dbg_flg)

%-------------------------------------------------------------------------------
%
% Update the reconstructed image based on the slider value
%
%-------------------------------------------------------------------------------
function sample_slider_Callback(hObject, eventdata, handles)
%-------------------------------------------------------------------------------
% Set globals
global dbmat clabs nvar extcond_fun nodes qplt_lims plot_info
%-------------------------------------------------------------------------------
plot_sel_rec(handles               , ...
    plot_info)

%-------------------------------------------------------------------------------
%
% The following three functions are radio button for selections of the
% slice or plane that is plot for individual reconstructions
%-------------------------------------------------------------------------------
function xyplane_rbut_Callback(hObject, eventdata, handles)
if get(handles.xyplane_rbut,'Value') == 1
    set(handles.yzplane_rbut,'Value',0)
    set(handles.xzplane_rbut,'Value',0)
    set(handles.slice_label,'String','Z:')
else
    set(handles.xyplane_rbut,'Value',1)   
end
update_slice_vals(handles);

function yzplane_rbut_Callback(hObject, eventdata, handles)
if get(handles.yzplane_rbut,'Value') == 1
    set(handles.xyplane_rbut,'Value',0)
    set(handles.xzplane_rbut,'Value',0)
    set(handles.slice_label,'String','X:')
else
    set(handles.yzplane_rbut,'Value',1)   
end
update_slice_vals(handles);

function xzplane_rbut_Callback(hObject, eventdata, handles)
if get(handles.xzplane_rbut,'Value') == 1
    set(handles.xyplane_rbut,'Value',0)
    set(handles.yzplane_rbut,'Value',0)
    set(handles.slice_label,'String','Y:')
else
    set(handles.xzplane_rbut,'Value',1)   
end
update_slice_vals(handles);

%-------------------------------------------------------------------------------
%
% This function update the textbox giving the value of the slice
%
%-------------------------------------------------------------------------------
function slice_slide_Callback(hObject, eventdata, handles)
update_slice_vals(handles);
%-------------------------------------------------------------------------------
function update_slice_vals(handles)
%-------------------------------------------------------------------------------
% Set globals
global dbmat clabs nvar extcond_fun nodes qplt_lims plot_infoslice_val
%-------------------------------------------------------------------------------
% Get the unique values of the z-values and fraction of z-value from the
% slider
if get(handles.xyplane_rbut,'Value') == 1
    uzs  = unique(nodes(:,3));
elseif get(handles.yzplane_rbut,'Value') == 1
    uzs  = unique(nodes(:,1));
elseif get(handles.xzplane_rbut,'Value') == 1
    uzs  = unique(nodes(:,2));
end    
frac = get(handles.slice_slide,'Value');
%-------------------------------------------------------------------------------
% Get the index and set the textbox string
ind  = round( (length(uzs)-1)*frac) + 1;
set(handles.slice_val,'String', num2str(uzs(ind)) )


%-------------------------------------------------------------------------------
% 
% Function to plot contours on the quality plots
% 
%-------------------------------------------------------------------------------
function plot_qcontours_Callback(hObject, eventdata, handles)
%-------------------------------------------------------------------------------
% Set globals
global dbmat clabs nvar extcond_fun nodes qplt_lims plot_info
%-------------------------------------------------------------------------------
% Get the contour tolerance values
qctol1 = str2num( get(handles.ctol_plot1,'String') );
qctol2 = str2num( get(handles.ctol_plot2,'String') );
qctol3 = str2num( get(handles.ctol_plot3,'String') );
%-------------------------------------------------------------------------------
plot_info.qctol1 = qctol1;
plot_info.qctol2 = qctol2;
plot_info.qctol3 = qctol3;
%-------------------------------------------------------------------------------
% Make the plots
make_qual_plots(handles, plot_info )

%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
%
% Unused automatically generated functions
%
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
% --- Executes during object creation, after setting all properties.
function const_drpdwn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to const_drpdwn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes on selection change in const_vals1.
function const_vals1_Callback(hObject, eventdata, handles)
% hObject    handle to const_vals1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns const_vals1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from const_vals1
% --- Executes during object creation, after setting all properties.
function const_vals1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to const_vals1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes when figure1 is resized.
function figure1_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
function rec_xvar_txtbox_Callback(hObject, eventdata, handles)
% hObject    handle to rec_xvar_txtbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of rec_xvar_txtbox as text
%        str2double(get(hObject,'String')) returns contents of rec_xvar_txtbox as a doubl
% --- Executes during object creation, after setting all properties.
function rec_xvar_txtbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rec_xvar_txtbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function rec_siginc_txtbox_Callback(hObject, eventdata, handles)
% hObject    handle to rec_siginc_txtbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of rec_siginc_txtbox as text
%        str2double(get(hObject,'String')) returns contents of rec_siginc_txtbox as a double
% --- Executes during object creation, after setting all properties.
function rec_siginc_txtbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rec_siginc_txtbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function rec_yvar_txtbox_Callback(hObject, eventdata, handles)
% hObject    handle to rec_yvar_txtbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of rec_yvar_txtbox as text
%        str2double(get(hObject,'String')) returns contents of rec_yvar_txtbox as a double
% --- Executes during object creation, after setting all properties.
function rec_yvar_txtbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rec_yvar_txtbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes on selection change in pnt_sel_axs.
function pnt_sel_axs_Callback(hObject, eventdata, handles)
% hObject    handle to pnt_sel_axs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: contents = cellstr(get(hObject,'String')) returns pnt_sel_axs contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pnt_sel_axs
% --- Executes during object creation, after setting all properties.
function pnt_sel_axs_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pnt_sel_axs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function recon_thresh_Callback(hObject, eventdata, handles)
% hObject    handle to recon_thresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of recon_thresh as text
%        str2double(get(hObject,'String')) returns contents of recon_thresh as a double
% --- Executes during object creation, after setting all properties.
function recon_thresh_CreateFcn(hObject, eventdata, handles)
% hObject    handle to recon_thresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes on selection change in dropdwn_2d.
function dropdwn_2d_Callback(hObject, eventdata, handles)
% hObject    handle to dropdwn_2d (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: contents = cellstr(get(hObject,'String')) returns dropdwn_2d contents as cell array
%        contents{get(hObject,'Value')} returns selected item from dropdwn_2d
% --- Executes during object creation, after setting all properties.
function dropdwn_2d_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dropdwn_2d (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes during object creation, after setting all properties.
function sample_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sample_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
function sample_txtbox_Callback(hObject, eventdata, handles)
% hObject    handle to sample_txtbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of sample_txtbox as text
%        str2double(get(hObject,'String')) returns contents of sample_txtbox as a double
% --- Executes during object creation, after setting all properties.
function sample_txtbox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sample_txtbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes during object creation, after setting all properties.
function plot_varx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to plot_varx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% --- Executes during object creation, after setting all properties.
function plot_1opt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to plot_1opt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes during object creation, after setting all properties.
function plot_2opt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to plot_2opt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
% --- Executes during object creation, after setting all properties.
function plot_3opt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to plot_3opt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on slider movement.
function slice_val_Callback(hObject, eventdata, handles)
% hObject    handle to slice_slide (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider



function slice_slide_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slice_slide (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



% --- Executes during object creation, after setting all properties.
function slice_val_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slice_val (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes during object creation, after setting all properties.
function plot_vary_CreateFcn(hObject, eventdata, handles)
% hObject    handle to plot_vary (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function ctol_plot1_Callback(hObject, eventdata, handles)
% hObject    handle to ctol_plot1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ctol_plot1 as text
%        str2double(get(hObject,'String')) returns contents of ctol_plot1 as a double


% --- Executes during object creation, after setting all properties.
function ctol_plot1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ctol_plot1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ctol_plot2_Callback(hObject, eventdata, handles)
% hObject    handle to ctol_plot2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ctol_plot2 as text
%        str2double(get(hObject,'String')) returns contents of ctol_plot2 as a double


% --- Executes during object creation, after setting all properties.
function ctol_plot2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ctol_plot2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ctol_plot3_Callback(hObject, eventdata, handles)
% hObject    handle to ctol_plot3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ctol_plot3 as text
%        str2double(get(hObject,'String')) returns contents of ctol_plot3 as a double


% --- Executes during object creation, after setting all properties.
function ctol_plot3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ctol_plot3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in const_vals2.
function const_vals2_Callback(hObject, eventdata, handles)
% hObject    handle to const_vals2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns const_vals2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from const_vals2


% --- Executes during object creation, after setting all properties.
function const_vals2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to const_vals2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in const_vals3.
function const_vals3_Callback(hObject, eventdata, handles)
% hObject    handle to const_vals3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns const_vals3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from const_vals3


% --- Executes during object creation, after setting all properties.
function const_vals3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to const_vals3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qualmet1_txtbx_Callback(hObject, eventdata, handles)
% hObject    handle to qualmet1_txtbx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qualmet1_txtbx as text
%        str2double(get(hObject,'String')) returns contents of qualmet1_txtbx as a double


% --- Executes during object creation, after setting all properties.
function qualmet1_txtbx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qualmet1_txtbx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qualmet2_txtbx_Callback(hObject, eventdata, handles)
% hObject    handle to qualmet2_txtbx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qualmet2_txtbx as text
%        str2double(get(hObject,'String')) returns contents of qualmet2_txtbx as a double


% --- Executes during object creation, after setting all properties.
function qualmet2_txtbx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qualmet2_txtbx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function qualmet3_txtbx_Callback(hObject, eventdata, handles)
% hObject    handle to qualmet3_txtbx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of qualmet3_txtbx as text
%        str2double(get(hObject,'String')) returns contents of qualmet3_txtbx as a double


% --- Executes during object creation, after setting all properties.
function qualmet3_txtbx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qualmet3_txtbx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function scrn_sav_Callback(hObject, eventdata, handles)
% hObject    handle to scrn_sav (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.figure1
handles.output
set(handles.output,'PaperPositionMode','auto')
saveas(handles.output,'testscrshot','tif')

% print(handles.output,'-dtiff','-r500','testscrshot')
