%-------------------------------------------------------------------------------
%
%                   extcond_generic_system_Test2
%
%-------------------------------------------------------------------------------
%
% Copyright (c) 2009 Trustees of Dartmouth College
% Written by Ethan K Murphy
% Hanover 15 December 2014
% 
% If this software is used please reference the following work:
% 
% Murphy EK, Mahara A, Odame KM, and Halter RJ EIT SysDAF: Electrical Impedance 
% Tomography System Design and feasibility Analysis Framework, submitted to
% Physiological Measurement December 2014
% 
%-------------------------------------------------------------------------------
% 
%                           Description
%
% This function loads the reconstructed conductivity values defined on the 
% reconstruction mesh for the given set of variables.  
%
%-------------------------------------------------------------------------------
function [sig_vec, true_inc] =            ...
    extcond_generic_system_Test2(         ...
    par_vals                            , ...
    samp_ind                            , ...
    plane_ids                           , ...
    recdat )

%-------------------------------------------------------------------------------
% Pull out the RMS from the par_vals vector
Recipper = par_vals(4);
RMS_val  = par_vals(3);
diam     = par_vals(1);
sig      = par_vals(2);


%-------------------------------------------------------------------------------
% Output message to the user

disp(' ')
disp('****************************************************************')
disp('These reconstruction files were not released with the current')
disp('version of the visualization software.  This decision was')
disp('simply based on the data size. The full set of reconstruction')
disp('files several GBs.')
disp('****************************************************************')
disp(' ')
error('No reconstruction files available. Further Deails Above')
