%-------------------------------------------------------------------------------
%
%                   construct_data_Generic_sys_Test1_reduced
%
%-------------------------------------------------------------------------------
%
% Copyright (c) 2009 Trustees of Dartmouth College
% Written by Ethan K Murphy
% Hanover 15 December 2014
% 
% If this software is used please reference the following work:
% 
% Murphy EK, Mahara A, Odame KM, and Halter RJ EIT SysDAF: Electrical Impedance 
% Tomography System Design and feasibility Analysis Framework, submitted to
% Physiological Measurement December 2014
% 
%-------------------------------------------------------------------------------
% 
%                           Description
%
% This function loads the reconstructed conductivity values defined on the 
% reconstruction mesh for the given set of variables.  
%
%-------------------------------------------------------------------------------
function [sig_vec, true_inc] =                    ...
    extcond_generic_sys_Test1_reduced(        ...
    par_vals                        , ...
    samp_ind                        , ...
    plane_ids                       , ...
    recdat )

%-------------------------------------------------------------------------------
% Pull out the RMS from the par_vals vector
RMS_val  = par_vals(3);
diam     = par_vals(1);
sig      = par_vals(2);


%-------------------------------------------------------------------------------
% Load the data
fn_recout   = ['gensysT1_rdc_d'         , ...
    ifdec(num2str(diam))                , ...
    '_sig'                              , ...
    ifdec(num2str(sig))];
eval(['load data/recon_repository/'     , ...
    'generic_system_Test1/'             , ...
    fn_recout])
load data/recon_repository/generic_system_Test1/gensysT1_rdc_corse2fine_mat

%-------------------------------------------------------------------------------
% Pick the column that corresponds to the given RMS value and sample value
[tmp,ind] = min( sum( ( ...
    slabs - repmat([RMS_val samp_ind],size(slabs,1),1) ).^2,2));
sig_vec   = corse2fine * sig_rec(:,ind);

%-------------------------------------------------------------------------------
% Get the boundary of the true inclusion
if norm( plane_ids - [1 2]) < 1e-6
    %---------------------------------------------------------------------------
    % Get the inclusion location
    cntpos = [0 0];
    diam   = par_vals(1);
    
    tht      = linspace(0,2*pi,100)';
    true_inc = [ ...
        diam/2 * cos(tht) + cntpos(1) ...
        diam/2 * sin(tht) + cntpos(2)];
     
else
    true_inc = -1;
end



