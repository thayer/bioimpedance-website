%-------------------------------------------------------------------------------
%
%                                ifdec
%
%-------------------------------------------------------------------------------
% 
%                           Description
%
% This function adds a o where there are .'s in strings. It helps when numeric 
% parameters are in file names.
%
%-------------------------------------------------------------------------------
function filename = ifdec(filename)

if isnumeric(filename) == 1
    filename = num2str(filename);
end

for i = 1:length(filename)
   if strcmp('.',filename(i))==1
       filename(i) = 'o';
   end
end