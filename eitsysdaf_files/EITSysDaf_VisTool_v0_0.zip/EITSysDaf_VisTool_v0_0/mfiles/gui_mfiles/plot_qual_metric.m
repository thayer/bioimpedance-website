%-------------------------------------------------------------------------------
%
%                          plot_qual_metric
%
%-------------------------------------------------------------------------------
%
% Copyright (c) 2009 Trustees of Dartmouth College
% Written by Ethan K Murphy
% Hanover 15 December 2014
% 
% If this software is used please reference the following work:
% 
% Murphy EK, Mahara A, Odame KM, and Halter RJ EIT SysDAF: Electrical Impedance 
% Tomography System Design and feasibility Analysis Framework, submitted to
% Physiological Measurement December 2014
% 
%-------------------------------------------------------------------------------
% 
%                           Description
%
% This function plots quality metrics.
%
%-------------------------------------------------------------------------------
function plot_qual_metric(            ...
    var1_mat, var2_mat              , ...
    mtrc_mat                        , ...
    logscl                          , ...
    vplt_xtics                      , ...
    vplt_ytics                      , ...    
    xlab_str,ylab_str,ttl_str       , ...
    cax_var                         , ...
    numIIVV,y                       , ...
    hax                             , ...
    qctol                           , ...
    dbg_flg )

%-------------------------------------------------------------------------------
% Set the axis
axes(hax);

%-------------------------------------------------------------------------------
% Get the contour information, if one is requested
if qctol > 0
    [C,h] = contour(var1_mat,var2_mat,mtrc_mat,[qctol; 2*qctol]);
end

%-------------------------------------------------------------------------------
% Plot the surface
surf(var1_mat, var2_mat     , ...
    mtrc_mat              , ...
    'edgecolor','none')

%-------------------------------------------------------------------------------
if numIIVV > 0
    hold on
    plot3(hax,numIIVV,y,max(mtrc_mat(:))+0.001,'xk','linewidth',3,'markersize',10)
    hold off
end

%-------------------------------------------------------------------------------
% Put in the contour
if qctol > 0    
    hold on
    plot_contour_atz(C,qctol,(max(mtrc_mat(:))+0.001),hax);
    hold off
end

%-------------------------------------------------------------------------------
% Formatting
xlabel(hax,xlab_str,'fontsize',16,'FontName','arial')
ylabel(hax,ylab_str,'fontsize',16,'FontName','arial')
title(hax,ttl_str,'fontsize',16,'FontName','arial')
if logscl(1) == 1
    % disp('set x-axis scale to log')
    set(hax,'xscale','log')
end
if logscl(2) == 1
    % disp('set y-axis scale to log')
    set(hax,'yscale','log')
end
set(hax,'xlim',[min(var1_mat(:)) max(var1_mat(:))])
set(hax,'ylim',[min(var2_mat(:)) max(var2_mat(:))])
if vplt_xtics(1) ~= -1
   set(hax,'xtick',vplt_xtics) 
end
if vplt_ytics(1) ~= -1
    set(hax,'ytick',vplt_ytics)
end
    
%-------------------------------------------------------------------------------
set(hax,'FontSize',16,'FontName','arial')
view(2)
if cax_var ~= -1
    caxis(cax_var)
end
colorbar
axis square


