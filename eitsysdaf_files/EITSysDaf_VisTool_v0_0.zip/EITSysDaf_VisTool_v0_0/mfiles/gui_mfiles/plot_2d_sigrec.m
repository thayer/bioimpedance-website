%-------------------------------------------------------------------------------
%
%                          plot_2d_sigrec
%
%-------------------------------------------------------------------------------
%
% Copyright (c) 2009 Trustees of Dartmouth College
% Written by Ethan K Murphy
% Hanover 15 December 2014
% 
% If this software is used please reference the following work:
% 
% Murphy EK, Mahara A, Odame KM, and Halter RJ EIT SysDAF: Electrical Impedance 
% Tomography System Design and feasibility Analysis Framework, submitted to
% Physiological Measurement December 2014
% 
%-------------------------------------------------------------------------------
% 
%                           Description
%
% This function plots the 2D reconstruction slice that was selected.  
%
%-------------------------------------------------------------------------------
function plot_2d_sigrec( ...
    TRI,topnode,sig_vec, ...   
    xmat,ymat           , ...
    thresh              , ...
    true_inc            , ...
    clims               , ...
    hax                 , ...
    dbg_flg)

axes(hax);

%---------------------------------------------------------------------------
% Plot the reconstruction
trisurf(TRI,topnode(:,1),topnode(:,2), ...
    sig_vec, ...
    'edgecolor','none')

hold on
%---------------------------------------------------------------------------
% Shift the data to a grid for plotting
sig_mat = griddata(         ...
    topnode(:,1)          , ...       % All numIIVV values
    topnode(:,2)          , ...       % All variable 2 values
    sig_vec               , ...       % All Reconstructed volumes
    xmat                , ...       % numIIVV grid values
    ymat                , ...       % variable 2 grid values
    'nearest');
cont_val = thresh*(max(sig_vec)-min(sig_vec)) + min(sig_vec);
[C,h] = contour(xmat,ymat,sig_mat,[cont_val cont_val]);


plot_contour_atz(C,cont_val,(max(sig_vec)+0.1),hax);
tht = linspace(0,2*pi,1000);

if size(true_inc,1) > 1
    plot3( ...
        true_inc(:,1), true_inc(:,2),...
        (max(sig_vec)+0.001)*ones(size(true_inc,1),1),...
        'k','linewidth',2)
end
hold off
colorbar
caxis(clims)
view(2)
axis off
axis equal