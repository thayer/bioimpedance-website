%-------------------------------------------------------------------------------
%
%                          plot_contour_atz
%
%-------------------------------------------------------------------------------
%
% Copyright (c) 2009 Trustees of Dartmouth College
% Written by Ethan K Murphy
% Hanover 15 December 2014
% 
% If this software is used please reference the following work:
% 
% Murphy EK, Mahara A, Odame KM, and Halter RJ EIT SysDAF: Electrical Impedance 
% Tomography System Design and feasibility Analysis Framework, submitted to
% Physiological Measurement December 2014
% 
%-------------------------------------------------------------------------------
% 
%                           Description
%
% This function plots contours in the surface and 2D reconstruction plots
%
%-------------------------------------------------------------------------------
function plot_contour_atz(C,cont_val,z,hax)
            
inds = find(  ...
    (C(1,:) == cont_val) & ...
    ( abs(C(2,:) - floor(C(2,:)) ) < 1e-8) );

for n = 1:length(inds)
    num_pts = C(2,inds(n));
    plot3(hax                               , ...
        C(1,(inds(n)+1):(inds(n)+num_pts))  , ...
        C(2,(inds(n)+1):(inds(n)+num_pts))  , ...
        z*ones(num_pts,1)                   , ...
        'm','linewidth',2)
    
end