%-------------------------------------------------------------------------------
%
%                   construct_data_Generic_sys_Test1_reduced
%
%-------------------------------------------------------------------------------
%
% Copyright (c) 2009 Trustees of Dartmouth College
% Written by Ethan K Murphy
% Hanover 15 December 2014
% 
% If this software is used please reference the following work:
% 
% Murphy EK, Mahara A, Odame KM, and Halter RJ EIT SysDAF: Electrical Impedance 
% Tomography System Design and feasibility Analysis Framework, submitted to
% Physiological Measurement December 2014
% 
%-------------------------------------------------------------------------------
% 
%                           Description
%
% This is an example file that illustrates the required form for the
% summary data to be used in the visualization tool. It is assumed that
% prior to this script being run one has constructed a database of
% reconstructions and calculated quality metrics on these reconstructions. 
%
% The are four main steps:
%   1.  Load database and set the number of variables, the number of random
%       draws, and the column labels
%   2.  Set the plotting parameters
%   3.  Set the FEM nodes file name and the function to load reconstruction 
%       data
%   4.  Save the data
% 
%-------------------------------------------------------------------------------
clear
clc
close all



%-------------------------------------------------------------------------------
%
%   1.  Load database and set the number of variables and column labels
%
%-------------------------------------------------------------------------------
% Load the main database 
load ../data/summary_data/generic_system_Test1_reduced dbmat
%-------------------------------------------------------------------------------
% Set the number of test parameters and system errors
nvar = 3;           
%-------------------------------------------------------------------------------
% Number of samples
numsamp = 8;
%-------------------------------------------------------------------------------
% Set the column labels
clabs = {'Diameter (cm)'                , ...   % Diameter
    'Conductivity (S/m)'                , ...   % Conductivity
    'RMS'                               , ...   % RMS
    'AVE VOL ERROR'                     , ...   % Volume Errors
    'MAX VOL ERROR'                     , ...   
    'MIN VOL ERROR'                     , ...   
    'STD VOL ERROR'                     , ...   
    'AVE RES ERROR'                     , ...   % RES Errors
    'MAX RES ERROR'                     , ...   
    'MIN RES ERROR'                     , ...   
    'STD RES ERROR'                     , ...       
    'AVE TSD'                           , ...   % True Shape Deformation values
    'MAX TSD'                           , ...   
    'MIN TSD'                           , ...   
    'STD TSD'                           , ...   % Percent measured/resovled
    'PERCENT MEAS > 1*RMS'              , ...
    'PERCENT MEAS > 2*RMS'              , ...
    'PERCENT MEAS > 3*RMS'              , ...
    'PERCENT MEAS > 4*RMS'              , ...
    'PERCENT MEAS > 5*RMS'              , ...
    'PERCENT MEAS > 6*RMS'              , ...
    }; 



%-------------------------------------------------------------------------------
%
%   2.  Set the plotting parameters
%
% In this version of the software there are limited amount of plotting 
% parameters. The parameters are as follows:
% 
%       2.a. Logarithmic (or not) flags for the variables
%       2.b. Scale and axis tick values for the variables
%       2.c. Axis limits for the quality metrics
%
%-------------------------------------------------------------------------------
% 2.a. Logarithmic (or not) flags for the variables.  1 = logarithmic
% scale, 0 = linear scale
plot_info.var_logscale = [0 0 1];
%-------------------------------------------------------------------------------
% 2.b. Scale and axis tick values for the variables. A value of -1 means
% that the code ignores the values. 
plot_info.vplt_tics{1} = [-1 -1];                       % Diameter (cm)
plot_info.vplt_tics{2} = [-1 -1];                       % Conductivity (S/m)
plot_info.vplt_tics{3} = [0.001 0.01 0.1 1 10 100];     % RMS
%-------------------------------------------------------------------------------
% 2.c. Axis limits for the quality metrics
plot_info.qplt_lims = [ ...
    -1 -1; ...      % AVE VOLUME ERROR
    -1 -1; ...      % MAX VOLUME ERROR
    -1 -1; ...      % MIN VOLUME ERROR
    -1 -1; ...      % STD VOLUME ERROR
    0 1; ...        % AVE RES ERROR
    0 1; ...        % MAX RES ERROR
    0 1; ...        % MIN RES ERROR
    -1 -1; ...      % STD RES ERROR
    0 2; ...        % AVE TSD
    0 2; ...        % MAX TSD
    0 2; ...        % MIN TSD
    -1 -1; ...      % STD TSD
    0 100; ...      % PERCENT MEASUREMENTS > 1*RMS
    0 100; ...      % PERCENT MEASUREMENTS > 2*RMS
    0 100; ...      % PERCENT MEASUREMENTS > 3*RMS
    0 100; ...      % PERCENT MEASUREMENTS > 4*RMS
    0 100; ...      % PERCENT MEASUREMENTS > 5*RMS
    0 100; ...      % PERCENT MEASUREMENTS > 6*RMS
    ];



%-------------------------------------------------------------------------------
%
%   3.  Set the FEM nodes file name and the function to load reconstruction 
%       data
%
%-------------------------------------------------------------------------------
% Set the mesh file name and path relative to the home directory of the
% visualization software
mesh_fname = 'data/mesh_data/generic_system_reconmesh';
%-------------------------------------------------------------------------------
% Set the function that returns condtuctivity values from the requested 
% reconstruction.  An example function that performs this task is 
%
%           extcond_generic_sys_Test1_reduced.m, 
%
% which can be found at 
%
%           /EITSysDaf_VisTool_v0_0/mfiles/recon_extract_mfiles
extcond_fun = @extcond_generic_sys_Test1_reduced;



%-------------------------------------------------------------------------------
%
%   4.  Save the data
%
%-------------------------------------------------------------------------------
save generic_system_Test1_reduced   ...
    dbmat                           ...         % Database
    nvar                            ...         % Number of variables
    numsamp                         ...         % Number of random draws
    clabs                           ...         % Column labels
    mesh_fname                      ...         % Node/mesh file name and path
    extcond_fun                     ...         % Extract Conductivity file for reconstruction
    plot_info                                   % Plotting parameters
    
    